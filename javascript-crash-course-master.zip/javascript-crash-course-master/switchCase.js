let value = 2;

switch (value) {
  case 0:
    console.log("It's a zero");
    break;
  case 1:
    console.log("It's a one");
    break;
  case 2:
    console.log("It's a two");
    break;
  default:
    console.log("No number found");
}

let str = "COUNTR";

switch (str) {
  case "NAME":
    console.log("It's a name");
    break;
  case "COUNTRY":
    console.log("It's a Country");
    break;
  case "CITY":
    console.log("It's a city");
    break;
  default:
    console.log("No string found");
}
