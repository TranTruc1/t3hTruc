// function any(){
// }

function print() {
  console.log("Function Has been Called");
}

print();
print();
print();
print();
print();
print();
print();
print();
print();

console.clear();

function print2(val) {
  console.log(val);
  return "HEYEYEY";
}

print2(1);
print2(5);
print2("Hey");

console.log(print2(1));
