import React from 'react'

export default function About(props) {
  return (
    <div>
        <h1 className='display-4'>About Contact Managerment</h1>
        <p className='text-secondary'>version 1.1.1</p>
    </div>
  )
}
